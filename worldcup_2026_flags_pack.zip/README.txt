# World Cup 2026 Flags Pack

المحتوى:
- `assets/flags/` يحتوي 48 علم PNG بخلفية شفافة.
- `flags_map.json` خريطة أسماء عربية/إنجليزية إلى ملف العلم.
- `flags_aliases_for_bot.py` قاموس جاهز تضيفه للبوت.
- `teams_48_checklist.csv` قائمة مراجعة لكل المنتخبات.

طريقة الاستخدام في البوت:
```python
from PIL import Image

flag_path = "assets/flags/france.png"
flag = Image.open(flag_path).convert("RGBA")
```

ملاحظة:
الأعلام هنا مرسومة من Emoji-style flags، وهذا مناسب للتصاميم السريعة داخل تيليجرام.
