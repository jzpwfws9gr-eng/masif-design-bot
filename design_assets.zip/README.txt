V17 design assets:
- assets/templates/*.png
- assets/logos/masif_logo_mark.png
- assets/logos/masif_logo_full.png

ارفع هذا الملف باسم design_assets.zip بجانب bot.py.
