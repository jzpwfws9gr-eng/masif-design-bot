قوالب تصميم المصيف للبوت:
- assets/templates/matches_template.png
- assets/templates/match_results_template.png
- assets/templates/group_standing_template.png
- assets/templates/scorers_template.png
ارفع design_assets.zip في نفس مكان bot.py، والكود يفكه تلقائيًا.
